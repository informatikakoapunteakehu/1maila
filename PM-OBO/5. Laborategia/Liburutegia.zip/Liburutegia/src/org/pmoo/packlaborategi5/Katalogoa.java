package org.pmoo.packlaborategi5;

public class Katalogoa{
	// atributuak
	private ListaLiburuak lista;
	private static Katalogoa nireKatalogoa=null;	
	
	// eraikitzailea
	
	private Katalogoa(){
		this.lista= new ListaLiburuak();
	}

 	// beste metodoak
 	
	public static Katalogoa getKatalogoa(){
		if(Katalogoa.nireKatalogoa==null){
			Katalogoa.nireKatalogoa=new Katalogoa();
		}
		return Katalogoa.nireKatalogoa;
	}
	
 	public int liburuKopuru(){
 		return this.lista.listarenTamaina();
 	}
 	 	
 	public Liburua bilatuLiburuaIdz(int pIdLiburua){
 		return this.lista.bilatuLiburuaIdz(pIdLiburua);
 	}
 	
 	public void mailegatuLiburua(int pIdLiburua, int pIdErabiltzailea){
 		ListaErabiltzaileak le=ListaErabiltzaileak.getListaErabiltzaileak();
 		Erabiltzailea e=le.bilatuErabiltzaileaIdz(pIdErabiltzailea);
 		Liburua l=this.lista.bilatuLiburuaIdz(pIdLiburua);
 		if(e.mailegatzekoMaximoaGainditua()){
 			System.out.println("Erabiltzailea maileguan izan ditzaken liburu kopuru maximora heldu da");
 		}
 		else if(le.norkDaukaMaileguan(l)!=null){
 			System.out.println("Liburua ez dago eskuragarri");
 		}
 		else{
 			e.gehituLiburua(l);
 		}
 	}

 	public void itzuliLiburua(int pIdLiburua){
 		ListaErabiltzaileak le=ListaErabiltzaileak.getListaErabiltzaileak();
 		Liburua l=this.lista.bilatuLiburuaIdz(pIdLiburua);
 		Erabiltzailea e=le.norkDaukaMaileguan(l);
 		e.kenduLiburua(l);
	}
 	
 	public void katalogatuLiburua(Liburua pLiburua){
 		if(!this.lista.badago(pLiburua)){
 			this.lista.gehituLiburua(pLiburua);
 			System.out.println("Liburua katalogatu da");
 		}
 		else{
 			System.out.println("Liburua katalogatu zen jada");
 		}
 	}

 	public void deskatalogatuLiburua(int pIdLiburua){
 		Liburua l=this.lista.bilatuLiburuaIdz(pIdLiburua);
 		if(this.lista.badago(l)){
 			this.lista.kenduLiburua(l);
 			System.out.println("Liburua deskatalogatu da");
 		}
 		else{
 			System.out.println("Liburua ez zegoen katalogatua");
 		}
 	}

 	public void inprimatu(){
 		this.lista.inprimatu();
 	}

 	public void erreseteatu(){
 		Katalogoa.nireKatalogoa=null;
 	}
}