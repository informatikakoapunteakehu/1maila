package org.pmoo.packlaborategi5;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaErabiltzaileak{
	// atributuak
	private ArrayList<Erabiltzailea> lista;
	private static ListaErabiltzaileak nireListaErabiltzaileak=null;
	
	// eraikitzailea
	
    private ListaErabiltzaileak(){
    	this.lista=new ArrayList<Erabiltzailea>();
    }
   	
    // beste metodoak
    
   	public static ListaErabiltzaileak getListaErabiltzaileak(){
   		if(ListaErabiltzaileak.nireListaErabiltzaileak==null){
   			ListaErabiltzaileak.nireListaErabiltzaileak= new ListaErabiltzaileak();
   		}
   		return ListaErabiltzaileak.nireListaErabiltzaileak;
   	}
   	
	public int erabiltzaileKopurua(){
		return this.lista.size();
   	}
   	
   	private Iterator<Erabiltzailea> getIteradorea(){
   		return this.lista.iterator();
   	}
    
   	public Erabiltzailea bilatuErabiltzaileaIdz(int pId){
   		boolean aur=false;
   		Erabiltzailea a;
   		Erabiltzailea e=null;
   		Iterator<Erabiltzailea> itr=this.getIteradorea();
   		while(itr.hasNext() && !aur){
   			a=itr.next();
   			if(a.idHauDu(pId)){
   				e=a;
   				aur=true;
   			}
   		}
   		return e;
   	}
   	
   	public boolean badagoIdBerdinekoErabiltzailerik(Erabiltzailea pErabiltzailea){
   		boolean bad=false;
   		Erabiltzailea e;
   		Iterator<Erabiltzailea> itr=this.getIteradorea();
   		while(itr.hasNext() && !bad){
   			e=itr.next();
   			if(e.idBerdinaDute(pErabiltzailea)){
   				bad=true;
   			}
   		}
   		return bad;
   	}
   	
   	public void erabiltzaileariAltaEman(Erabiltzailea pErabiltzailea){
   		if(!badagoIdBerdinekoErabiltzailerik(pErabiltzailea)){
   			this.lista.add(pErabiltzailea);
   		}
   	}

	public void erabiltzaileaBajaEman(Erabiltzailea pErabiltzailea){//int pIdErabiltzailea
		this.lista.remove(pErabiltzailea);
   	}

   	public Erabiltzailea norkDaukaMaileguan(Liburua pLiburua){
   		boolean aur=false;
   		Erabiltzailea a;
   		Erabiltzailea e=null;
   		Iterator<Erabiltzailea> itr=this.getIteradorea();
   		while(itr.hasNext() && !aur){
   			a=itr.next();
   			if(a.maileguanDu(pLiburua)){
   				e=a;
   				aur=true;
   			}
   		}
   		return e;
   	}

   	public void inprimatu(){
   		Erabiltzailea e;
   		Iterator<Erabiltzailea> itr=this.getIteradorea();
   		System.out.println("Erabiltzaile kopurua: "+this.erabiltzaileKopurua());
   		while(itr.hasNext()){
   			e=itr.next();
   			e.inprimatu();
   		}
   	}
   
   	public void erreseteatu(){
   		ListaErabiltzaileak.nireListaErabiltzaileak=null;
   	}
}