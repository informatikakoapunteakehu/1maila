package org.pmoo.packlaborategi5;

public class Liburua{
	
	// atributuak
	private String titulua;
	private String idazlea;
	private int idLiburua; 

	// eraikitzailea
	public Liburua(String pTitulua, String pIdazlea, int pIdLiburua){
		this.titulua=pTitulua;
		this.idazlea=pIdazlea;
		this.idLiburua=pIdLiburua;
	} 
	
	// beste metodoak
	
	public boolean idHauDu(int pIdLiburua){
		if(this.idLiburua==pIdLiburua){
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean idBerdinaDute(Liburua pLiburua){
		return pLiburua.idHauDu(this.idLiburua);
	}
	
	public void inprimatu(){
		System.out.println(this.titulua+" - "+this.idazlea+" - "+this.idLiburua);
	}
}