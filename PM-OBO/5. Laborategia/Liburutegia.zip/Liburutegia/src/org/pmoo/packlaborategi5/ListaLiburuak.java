package org.pmoo.packlaborategi5;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaLiburuak{
    // atributuak	
	private ArrayList<Liburua> lista;
	
	// eraikitzailea
	
	public ListaLiburuak(){
		lista=new ArrayList<Liburua>();
	}

	// beste metodoak
	
	public int listarenTamaina(){
		return this.lista.size();
	}
	 
	private Iterator<Liburua> getIteradorea(){
		return this.lista.iterator();
	}
  
	public Liburua bilatuLiburuaIdz(int pIdLiburua){
		boolean aur=false;
		Liburua a=null;
		Liburua b=null;
		Iterator<Liburua> itr=this.getIteradorea();
		while(itr.hasNext() && !aur){
			b=itr.next();
			if(b.idHauDu(pIdLiburua)){
				a=b;
				aur=true;
			}
		}
		return a;
	}
  
	public boolean badago(Liburua pLiburua){
		return this.lista.contains(pLiburua);
	}
	
	public boolean idBerdinekoLibururikBaAlDa(Liburua pLiburua){
		boolean aur=false;
		Liburua b=null;
		Iterator<Liburua> itr=this.getIteradorea();
		while(itr.hasNext() && !aur){
			b=itr.next();
			if(b.idBerdinaDute(pLiburua)){
				aur=true;
			}
		}
		return aur;
	}
	
	public void gehituLiburua(Liburua pLiburua){
		if (!this.idBerdinekoLibururikBaAlDa(pLiburua)){
			this.lista.add(pLiburua);
		}
    }
	
	public void kenduLiburua(Liburua pLiburua){
		this.lista.remove(pLiburua);
	}
	
	public void inprimatu(){
		Liburua a;
		Iterator<Liburua> itr=this.getIteradorea();
		while(itr.hasNext()){
			a=itr.next();
			a.inprimatu();
		}
	}
}