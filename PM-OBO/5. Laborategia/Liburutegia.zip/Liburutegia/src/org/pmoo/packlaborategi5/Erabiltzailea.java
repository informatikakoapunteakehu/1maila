package org.pmoo.packlaborategi5;

public class Erabiltzailea{
	//atributuak
	private int idErabiltzailea;
	private String izenOsoa;
	private int maxLiburuak=3;
	private ListaLiburuak liburuMailegatuak;
	
	//eraikitzailea
	
	public Erabiltzailea(int pIdErabiltzaile, String pIzenOsoa){
		this.idErabiltzailea=pIdErabiltzaile;
		this.izenOsoa=pIzenOsoa;
		this.liburuMailegatuak=new ListaLiburuak();
	}
	
	// beste metodoak
	
	public boolean idHauDu(int pId){
		if(this.idErabiltzailea==pId){
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean idBerdinaDute(Erabiltzailea pErabiltzailea){
		return pErabiltzailea.idHauDu(this.idErabiltzailea);
	}
	
	public boolean mailegatzekoMaximoaGainditua(){
		if(this.liburuMailegatuak.listarenTamaina()==this.maxLiburuak){
			return true;
		}
		else{
			return false;
		}
	}
	
	public void gehituLiburua(Liburua pLiburua){
		this.liburuMailegatuak.gehituLiburua(pLiburua);
	}
	
	public void kenduLiburua(Liburua pLiburua){
		this.liburuMailegatuak.kenduLiburua(pLiburua);
	}
	
	public boolean maileguanDu(Liburua pLiburua){
		return this.liburuMailegatuak.badago(pLiburua);
	}
	
	public void inprimatu(){
		System.out.println(this.izenOsoa+" - "+this.idErabiltzailea);
		if(this.liburuMailegatuak.listarenTamaina()>0){
			System.out.println("Liburu hauek ditu maileguan:");
			this.liburuMailegatuak.inprimatu();
		}
		else{
			System.out.println("Ez du libururik maileguan");
		}
	}
}