package org.pmoo.packlaborategi5;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ErabiltzaileaTest{
	
	private Erabiltzailea e1,e2,e3,e4;
	private Liburua l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;

	@Before
	public void setUp() throws Exception{
		e1=new Erabiltzailea(36,"Andoni Bermo");
		e2=new Erabiltzailea(26,"Eneko Sampedro");
		e3=new Erabiltzailea(62,"Julen Diez");
		e4=new Erabiltzailea(39,"Alain Carpio");
		l1= new Liburua("Nidalee OP", "Anonymous", 36);
		l2= new Liburua("Pls nerf Nidalee", "Andoni Bermo", 41);
		l3= new Liburua("Urgot's rework incoming", "Morello", 26);
		l4= new Liburua("TLOTR 1", "JRT", 54);
		l5= new Liburua("TLOTR 2", "JRT", 27);
		l6= new Liburua("TLOTR 3", "JRT", 13);
		l7= new Liburua("TLOTR 4 ?!?", "JRT ?!?", 14);
		l8= new Liburua("-+-", "Anonymous", 98);
		l9= new Liburua("+-+", "Anonymous", 89);
		l10= new Liburua("+++", "Anonymous", 101);
		e1.gehituLiburua(l1);
		e1.gehituLiburua(l2);
		e1.gehituLiburua(l3);
		e2.gehituLiburua(l4);
		e2.gehituLiburua(l5);
		e2.gehituLiburua(l6);
		e3.gehituLiburua(l7);
		e3.gehituLiburua(l8);
	}

	@After
	public void tearDown() throws Exception{
		e1=null;
		e2=null;
		e3=null;
		e4=null;
		l1=null;
		l2=null;
		l3=null;
		l4=null;
		l5=null;
		l6=null;
		l7=null;
		l8=null;
		l9=null;
		l10=null;
	}

	@Test
	public void testIdHauDu(){
		assertTrue(e1.idHauDu(36));
		assertTrue(e2.idHauDu(26));
		assertTrue(e3.idHauDu(62));
		assertFalse(e1.idHauDu(37));
		assertFalse(e2.idHauDu(1));
		assertFalse(e3.idHauDu(61));
	}
	
	@Test
	public void testIdBerdinaDute(){
		assertTrue(e1.idBerdinaDute(e1));
		assertFalse(e2.idBerdinaDute(e1));
		assertFalse(e3.idBerdinaDute(e1));
		e1=new Erabiltzailea(62,"Julen Diez");
		assertTrue(e1.idBerdinaDute(e3));
	}
	
	@Test
	public void testMailegatzekoMaximoaGainditua(){
		assertTrue(e1.mailegatzekoMaximoaGainditua());
		assertTrue(e2.mailegatzekoMaximoaGainditua());
		assertFalse(e3.mailegatzekoMaximoaGainditua());
	}
	
	@Test
	public void testGehituLiburua(){
		assertFalse(e3.mailegatzekoMaximoaGainditua());
		assertFalse(e3.maileguanDu(l9));
		e3.gehituLiburua(l9);
		assertTrue(e3.mailegatzekoMaximoaGainditua());
		assertTrue(e3.maileguanDu(l9));
		assertFalse(e4.maileguanDu(l10));
		e4.gehituLiburua(l10);
		assertTrue(e4.maileguanDu(l10));
	}
	
	@Test
	public void testKenduLiburua(){
		assertTrue(e2.mailegatzekoMaximoaGainditua());
		assertTrue(e2.maileguanDu(l6));
		e2.kenduLiburua(l6);
		assertFalse(e3.mailegatzekoMaximoaGainditua());
		assertFalse(e3.maileguanDu(l6));
		assertTrue(e3.maileguanDu(l7));
		e3.kenduLiburua(l7);
		assertFalse(e3.maileguanDu(l7));
	}
	
	@Test
	public void testMaileguanDu(){
		assertTrue(e1.maileguanDu(l1));
		assertTrue(e2.maileguanDu(l4));
		assertTrue(e3.maileguanDu(l7));
		assertFalse(e1.maileguanDu(l5));
		assertFalse(e2.maileguanDu(l8));
		assertFalse(e3.maileguanDu(l1));
	}
	
	@Test
	public void testInprimatu(){
		e1.inprimatu();
		e2.inprimatu();
		e3.inprimatu();
		e4.inprimatu();
		assertNotSame(e1,e2);
		assertNotSame(e1,e3);
		assertNotSame(e1,e4);
	}
}