package org.pmoo.packlaborategi5;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaLiburuakTest{
	
	private ListaLiburuak lb1,lb2,lb3,lb4;
	private Liburua l1,l2,l3,l4,l5,l6,l7,l8,l9,l10;

	@Before
	public void setUp() throws Exception{
		lb1= new ListaLiburuak();
		lb2= new ListaLiburuak();
		lb3= new ListaLiburuak();
		lb4= new ListaLiburuak();
		l1= new Liburua("Nidalee OP", "Anonymous =P", 36);
		l2= new Liburua("Pls nerf Nidalee", "Andoni Bermo", 41);
		l3= new Liburua("Urgot's rework incoming", "Morello", 26);
		l4= new Liburua("TLOTR 1", "JRT", 54);
		l5= new Liburua("TLOTR 2", "JRT", 27);
		l6= new Liburua("TLOTR 3", "JRT", 13);
		l7= new Liburua("TLOTR 4 ?!?", "JRT ?!?", 14);
		l8= new Liburua("-+-", "Anonymous", 98);
		l9= new Liburua("+-+", "Anonymous", 89);
		l10= new Liburua("+++", "Anonymous", 101);
		lb1.gehituLiburua(l1);
		lb1.gehituLiburua(l2);
		lb1.gehituLiburua(l3);
		lb2.gehituLiburua(l4);
		lb2.gehituLiburua(l5);
		lb2.gehituLiburua(l6);
		lb2.gehituLiburua(l7);
		lb3.gehituLiburua(l8);
		lb3.gehituLiburua(l9);
	}

	@After
	public void tearDown() throws Exception{
		lb1=null;
		lb2=null;
		lb3=null;
		lb4=null;
		l1=null;
		l2=null;
		l3=null;
		l4=null;
		l5=null;
		l6=null;
		l7=null;
		l8=null;
		l9=null;
		l10=null;
	}

	@Test
	public void testListarenTamaina(){
		assertSame(lb1.listarenTamaina(),3);
		assertSame(lb2.listarenTamaina(),4);
		assertSame(lb3.listarenTamaina(),2);
		assertSame(lb4.listarenTamaina(),0);
		assertNotSame(lb1.listarenTamaina(),1);
		assertNotSame(lb1.listarenTamaina(),0);
	}
	
	@Test
	public void testBilatuLiburuaIdz(){
		assertSame(lb1.bilatuLiburuaIdz(36),l1);
		assertSame(lb2.bilatuLiburuaIdz(27),l5);
		assertSame(lb2.bilatuLiburuaIdz(13),l6);
		assertSame(lb3.bilatuLiburuaIdz(98),l8);
		assertNotSame(lb2.bilatuLiburuaIdz(36),l1);
		assertNotSame(lb1.bilatuLiburuaIdz(1),l10);
		assertSame(lb4.bilatuLiburuaIdz(1),null);
	}
	
	@Test
	public void testBadago(){
		assertTrue(lb1.badago(l1));
		assertTrue(lb2.badago(l4));
		assertTrue(lb3.badago(l9));
		assertFalse(lb1.badago(l5));
		assertFalse(lb2.badago(l2));
		assertFalse(lb3.badago(l6));
		assertFalse(lb4.badago(l1));
	}
	
	@Test
	public void testIdBerdinekoLibururikBaAlDa(){
		assertTrue(lb1.idBerdinekoLibururikBaAlDa(l1));
		assertTrue(lb2.idBerdinekoLibururikBaAlDa(l4));
		assertTrue(lb3.idBerdinekoLibururikBaAlDa(l9));
		assertFalse(lb1.idBerdinekoLibururikBaAlDa(l5));
		assertFalse(lb2.idBerdinekoLibururikBaAlDa(l2));
		assertFalse(lb3.idBerdinekoLibururikBaAlDa(l6));
		assertFalse(lb4.idBerdinekoLibururikBaAlDa(l1));
	}
	
	@Test
	public void testGehituLiburua(){
		assertSame(lb1.listarenTamaina(),3);
		lb1.gehituLiburua(l10);
		assertSame(lb1.listarenTamaina(),4);
		lb1.gehituLiburua(l1);
		assertSame(lb1.listarenTamaina(),4);
		assertSame(lb2.listarenTamaina(),4);
		lb2.gehituLiburua(l10);
		assertSame(lb2.listarenTamaina(),5);
		assertSame(lb3.listarenTamaina(),2);
		lb3.gehituLiburua(l10);
		assertSame(lb3.listarenTamaina(),3);
		lb3.gehituLiburua(l8);
		assertSame(lb3.listarenTamaina(),3);
		assertNotSame(lb4.listarenTamaina(),1);
		lb4.gehituLiburua(l10);
		assertSame(lb4.listarenTamaina(),1);
	}
	
	@Test
	public void testKenduLiburua(){
		assertSame(lb1.listarenTamaina(),3);
		lb1.kenduLiburua(l1);
		assertSame(lb1.listarenTamaina(),2);
		assertSame(lb2.listarenTamaina(),4);
		lb2.kenduLiburua(l4);
		assertSame(lb2.listarenTamaina(),3);
		assertSame(lb3.listarenTamaina(),2);
		lb3.kenduLiburua(l9);
		assertSame(lb3.listarenTamaina(),1);
		lb3.kenduLiburua(l8);
		assertSame(lb3.listarenTamaina(),0);
	}
	
	@Test
	public void testInprimatu(){
		lb1.inprimatu();
		lb2.inprimatu();
		lb3.inprimatu();
		lb4.inprimatu();
		assertNotSame(lb1,lb2);
		assertNotSame(lb1,lb3);
		assertNotSame(lb1,lb4);
	}
}