package org.pmoo.packlaborategi5;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaErabiltzaileakTest{
	
	private Katalogoa k;
	private ListaErabiltzaileak l;
	private Erabiltzailea e1,e2,e3,e4,e5;
	private Liburua l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;

	@Before
	public void setUp() throws Exception{
		k=Katalogoa.getKatalogoa();
		l=ListaErabiltzaileak.getListaErabiltzaileak();
		e1=new Erabiltzailea(36,"Andoni Bermo");
		e2=new Erabiltzailea(26,"Eneko Sampedro");
		e3=new Erabiltzailea(62,"Julen Diez");
		e4=new Erabiltzailea(39,"Alain Carpio");
		e5=new Erabiltzailea(72,"Gontzal Pujana");
		l1= new Liburua("Nidalee OP", "Anonymous", 36);
		l2= new Liburua("Pls nerf Nidalee", "Andoni Bermo", 41);
		l3= new Liburua("Urgot's rework incoming", "Morello", 26);
		l4= new Liburua("TLOTR 1", "JRT", 54);
		l5= new Liburua("TLOTR 2", "JRT", 27);
		l6= new Liburua("TLOTR 3", "JRT", 13);
		l7= new Liburua("TLOTR 4 ?!?", "JRT ?!?", 14);
		l8= new Liburua("-+-", "Anonymous", 98);
		l9= new Liburua("+-+", "Anonymous", 89);
		l10= new Liburua("+++", "Anonymous", 101);
		l11= new Liburua("---", "Anonymous", 11);
		k.katalogatuLiburua(l1);
		k.katalogatuLiburua(l2);
		k.katalogatuLiburua(l3);
		k.katalogatuLiburua(l4);
		k.katalogatuLiburua(l5);
		k.katalogatuLiburua(l6);
		k.katalogatuLiburua(l7);
		k.katalogatuLiburua(l8);
		k.katalogatuLiburua(l9);
		e1.gehituLiburua(l1);
		e1.gehituLiburua(l2);
		e1.gehituLiburua(l3);
		e2.gehituLiburua(l4);
		e2.gehituLiburua(l5);
		e2.gehituLiburua(l6);
		e3.gehituLiburua(l7);
		e3.gehituLiburua(l8);
		l.erabiltzaileariAltaEman(e1);
		l.erabiltzaileariAltaEman(e2);
		l.erabiltzaileariAltaEman(e3);
		l.erabiltzaileariAltaEman(e4);
	}

	@After
	public void tearDown() throws Exception{
		k.erreseteatu();
		l.erreseteatu();
		e1=null;
		e2=null;
		e3=null;
		e4=null;
		e5=null;
		l1=null;
		l2=null;
		l3=null;
		l4=null;
		l5=null;
		l6=null;
		l7=null;
		l8=null;
		l9=null;
		l10=null;
		l11=null;
	}

	@Test
	public void testGetListaErabiltzaileak(){
		ListaErabiltzaileak le=null;
		assertNotSame(l,le);
		le=ListaErabiltzaileak.getListaErabiltzaileak();
		assertSame(l,le);
	}
	
	@Test
	public void testErabiltzaileKopurua(){
		assertSame(l.erabiltzaileKopurua(),4);
		l.erabiltzaileaBajaEman(e1);
		assertSame(l.erabiltzaileKopurua(),3);
	}
	
	@Test
	public void testBilatuErabiltzaileaIdz(){
		assertSame(l.bilatuErabiltzaileaIdz(36),e1);
		assertSame(l.bilatuErabiltzaileaIdz(26),e2);
		assertSame(l.bilatuErabiltzaileaIdz(99),null);
	}
	
	@Test
	public void testBadagoIdBerdinekoErabiltzailerik(){
		assertTrue(l.badagoIdBerdinekoErabiltzailerik(e1));
		assertTrue(l.badagoIdBerdinekoErabiltzailerik(e2));
		assertTrue(l.badagoIdBerdinekoErabiltzailerik(e4));
		assertFalse(l.badagoIdBerdinekoErabiltzailerik(e5));
	}
	
	@Test
	public void testErabiltzaileariAltaEman(){
		assertSame(l.erabiltzaileKopurua(),4);
		l.erabiltzaileariAltaEman(e5);
		assertSame(l.erabiltzaileKopurua(),5);
	}
	
	@Test
	public void testErabiltzaileaBajaEman(){
		assertSame(l.erabiltzaileKopurua(),4);
		l.erabiltzaileaBajaEman(e1);
		assertSame(l.erabiltzaileKopurua(),3);
		l.erabiltzaileaBajaEman(e4);
		assertSame(l.erabiltzaileKopurua(),2);
	}
	
	
	@Test
	public void testNorkDaukaMaileguan(){
		assertSame(l.norkDaukaMaileguan(l1),e1);
		assertSame(l.norkDaukaMaileguan(l3),e1);
		assertSame(l.norkDaukaMaileguan(l5),e2);
		assertNotSame(l.norkDaukaMaileguan(l7),e2);
		assertSame(l.norkDaukaMaileguan(l8),e3);
		assertSame(l.norkDaukaMaileguan(l10),null);
		assertSame(l.norkDaukaMaileguan(l11),null);
	}
	
	@Test
	public void testInprimatu(){
		assertNotSame(e1,null);
		l.inprimatu();
		assertSame(e1,e1);
		assertNotSame(e1,e2);
	}
	
	@Test
	public void testErreseteatu(){
		ListaErabiltzaileak le;
		le=ListaErabiltzaileak.getListaErabiltzaileak();
		assertSame(l,le);
		l.erreseteatu();
		l=ListaErabiltzaileak.getListaErabiltzaileak();
		assertNotSame(l,le);
	}
}