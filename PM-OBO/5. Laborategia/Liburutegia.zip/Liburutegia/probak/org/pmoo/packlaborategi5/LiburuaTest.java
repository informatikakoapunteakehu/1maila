package org.pmoo.packlaborategi5;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LiburuaTest{
	
	private Liburua l1;
	private Liburua l2;
	private Liburua l3;

	@Before
	public void setUp() throws Exception{
		l1= new Liburua("Nidalee OP", "Anonymous", 36);
		l2= new Liburua("Pls nerf Nidalee", "Andoni Bermo", 41);
		l3= new Liburua("Urgot's rework incoming", "Morello", 26);
	}

	@After
	public void tearDown() throws Exception{
		l1=null;
		l2=null;
		l3=null;
	}

	@Test
	public void testIdHauDu(){
		assertTrue(l1.idHauDu(36));
		assertTrue(l2.idHauDu(41));
		assertTrue(l3.idHauDu(26));
		assertFalse(l1.idHauDu(35));
		assertFalse(l2.idHauDu(1));
		assertFalse(l3.idHauDu(36));
	}
	
	@Test
	public void testIdBerdinaDute(){
		assertFalse(l1.idBerdinaDute(l2));
		assertFalse(l1.idBerdinaDute(l3));
		assertTrue(l1.idBerdinaDute(l1));
		assertTrue(l2.idBerdinaDute(l2));
		l1= new Liburua("Urgot's rework incoming", "Morello", 26);
		assertTrue(l3.idBerdinaDute(l1));
	}
	
	@Test
	public void testInprimatu(){
		l1.inprimatu();
		l2.inprimatu();
		l3.inprimatu();
		assertNotSame(l1,l2);
		assertNotSame(l2,l3);
		assertNotSame(l1,l3);
	}
}