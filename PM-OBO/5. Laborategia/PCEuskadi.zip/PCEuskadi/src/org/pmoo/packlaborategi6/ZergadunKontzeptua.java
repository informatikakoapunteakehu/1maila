package org.pmoo.packlaborategi6;

public abstract class ZergadunKontzeptua extends Kontzeptua {
    private static double ehunekoa;

    public ZergadunKontzeptua(double pZenbatekoGordina){
    	super(pZenbatekoGordina);
    }
    
    public double kalkulatuDirua(){
        return (this.getZenbatekoGordina() - this.getZenbatekoGordina()*ehunekoa);
    }

}
