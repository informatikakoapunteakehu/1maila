package org.pmoo.packlaborategi6;

public abstract class Kontzeptua {
	
    private double zenbatekoGordina;

    public Kontzeptua(double pZenbatekoGordina){
    	this.zenbatekoGordina = pZenbatekoGordina;
    }

    public abstract double kalkulatuDirua();

    protected double getZenbatekoGordina(){
        return this.zenbatekoGordina;
    }

}
