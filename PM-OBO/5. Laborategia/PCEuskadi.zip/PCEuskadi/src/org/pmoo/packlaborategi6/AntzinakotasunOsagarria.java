package org.pmoo.packlaborategi6;

public class AntzinakotasunOsagarria extends Osagarria {
    private static int zerga = 10;
    private int urteKopurua;
    private String helbidea;

    public AntzinakotasunOsagarria(double pZenbatekoGordina, int pUrteKopurua, String pHelbidea){
    	super(pZenbatekoGordina);
    	this.urteKopurua = pUrteKopurua;
    	this.helbidea = pHelbidea;
    }

    public double kalkulatuDirua(){
        return (super.kalkulatuDirua() - zerga)*(this.urteKopurua-10);
    }

}
