package org.pmoo.packlaborategi6;

public class ErantzukizunOsagarria extends org.pmoo.packlaborategi6.Osagarria {
    private static int zerga = 20;
    private String helbidea;

    public ErantzukizunOsagarria(double pZenbatekoGordina, String pHelbidea){
    	super(pZenbatekoGordina);
    	this.helbidea = pHelbidea;
    }

    public double kalkulatuDirua(){
        return super.kalkulatuDirua() - zerga;
    }

}
