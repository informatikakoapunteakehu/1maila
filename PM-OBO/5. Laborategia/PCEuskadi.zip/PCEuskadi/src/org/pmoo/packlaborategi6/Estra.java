package org.pmoo.packlaborategi6;

public class Estra extends ZergadunKontzeptua {
    private int orduEstrakKop;
    private double diruOrduEstra;
    private String lanarenJustifikazioa;
    private static double ehunekoa = 0.1;

    public Estra(double pZenbatekoGordina, int pOrduEstrakKop, double pDiruOrduEstra, String pLanarenJustifikazioa){
    	super(pZenbatekoGordina);
    	this.orduEstrakKop = pOrduEstrakKop;
    	this.diruOrduEstra = pDiruOrduEstra;
    	this.lanarenJustifikazioa = pLanarenJustifikazioa;
    }

    public double kalkulatuDirua(){
        return (this.orduEstrakKop*this.diruOrduEstra) - (this.orduEstrakKop*this.diruOrduEstra*ehunekoa);
    }

}
