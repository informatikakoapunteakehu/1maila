package org.pmoo.packlaborategi6;

public class HelbideOsagarria extends Osagarria {
    private static int zerga = 50;
    private String helbidea;

    public HelbideOsagarria(double pZenbatekoGordina, String pHelbidea){
    	super(pZenbatekoGordina);
    	this.helbidea = pHelbidea;
    }

    public double kalkulatuDirua(){
        return super.kalkulatuDirua() - zerga;
    }

}
