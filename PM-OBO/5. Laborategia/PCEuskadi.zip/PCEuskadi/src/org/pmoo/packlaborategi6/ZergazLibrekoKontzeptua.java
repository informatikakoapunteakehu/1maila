package org.pmoo.packlaborategi6;

public class ZergazLibrekoKontzeptua extends Kontzeptua {
    private int orduKop;
    private String deskribapena;

    public ZergazLibrekoKontzeptua(double pZenbatekoGordina, int pOrduKop, String pDeskribapena){
    	super(pZenbatekoGordina);
    	this.orduKop = pOrduKop;
    	this.deskribapena = pDeskribapena;
    }

    public double kalkulatuDirua(){
        return (this.orduKop * this.getZenbatekoGordina());
    }

}
