package org.pmoo.packlaborategi6;

public abstract class Osagarria extends ZergadunKontzeptua {

    public Osagarria(double pZenbatekoGordina){
    	super(pZenbatekoGordina);
    }

}
