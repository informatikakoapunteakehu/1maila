package org.pmoo.packlaborategi6;

public class OinarrizkoSoldata extends ZergadunKontzeptua {
    private int identikadore;

    public OinarrizkoSoldata(double pZenbatekoGordina, int pIdentifikadore){
    	super(pZenbatekoGordina);
    	this.identikadore = pIdentifikadore;
    }
}
